"""API routes package."""
from app.api.routes import router

__all__ = ["router"]
