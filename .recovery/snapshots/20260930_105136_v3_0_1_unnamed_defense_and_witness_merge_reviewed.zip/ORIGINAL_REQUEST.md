# Original User Request

## 2026-09-14T15:39:19Z

Aplicação completa para confecção automatizada e interativa de resumos de processos judiciais a partir de autos integrais em PDF extraídos do sistema PJe, gerando documentos formatados em `.docx` para guiar magistrados na condução de audiências judiciais criminais (AIJ, ANPP e afins), com suporte a motor duplo (IA Gemini e Heurístico 100% Offline) e interface web moderna inspirada no Google Stitch e Nano Banana.

Working directory: `c:\Users\f201503\Documents\Resumo para audiência`
Integrity mode: development

## Reference Materials
- Pastas e arquivos de exemplo de processos e resumos já confeccionados pelo usuário no diretório:
  - `Proc. 0801889-53.2023.8.20.5001` (PDF e Resumo DOCX de referência)
  - `Proc. 0820550-12.2025.8.20.5001` (PDF e Resumo DOCX de referência)
  - `Proc. 0821902-39.2024.8.20.5001` (PDF e Resumo DOCX de referência)
  - `Proc. 0860849-94.2026.8.20.5001` (PDF e Resumo DOCX de referência)
  - `Proc. 0876503-58.2025.8.20.5001` (PDF e Resumo DOCX de referência)

## Requirements

### R1. Motor Selecionável de Ingestão e Processamento (Modo IA vs. Modo 100% Offline)
O sistema deve disponibilizar na interface uma opção clara de alternância entre dois motores de processamento, seguindo estritamente o protocolo selecionado:
1. **Modo 1 (IA Gemini + Extração Estruturada / OCR):** Ingestão de texto e imagens/peças digitalizadas via PyMuPDF/OCR, enviando os dados estruturados e peças-chave para processamento com a API do Google Gemini, realizando análise jurídica aprofundada, síntese de denúncias extensas e correlação de atos.
2. **Modo 2 (Motor 100% Offline e Local):** Processamento local utilizando OCR Tesseract, expressões regulares especializadas na estrutura documental do PJe e heurísticas de texto, operando com total privacidade e sem qualquer requisição externa à rede.

### R2. Síntese e Extração Fiel à Estrutura e Linguagem dos Modelos Judiciais
A minuta deve replicar a estrutura, a terminologia e o nível de detalhamento dos arquivos `Resumo - *.docx` fornecidos:
1. **Cabeçalho:** Número do processo, tipo de ato (AIJ, ANPP, etc.), data, horário, link de videoconferência (Teams/Meet) ou presencial, Promotor de Justiça, Réu(s) com situação prisional e ID de intimação, e Defesa técnica (OAB particular ou Defensoria Pública).
2. **Qualificação:** Nome em caixa alta, nacionalidade, estado civil, profissão, naturalidade, RG, CPF, idade à época dos fatos, data de nascimento, filiação materna/paterna, endereço domiciliar e telefone.
3. **Imputação:** Tipificação penal exata com artigos, parágrafos, incisos e leis especiais.
4. **Resumo dos Fatos:** Transcrição dos fatos narrados na denúncia (em ~99% dos casos); realização de resumo conciso apenas se a denúncia for excessivamente longa; indicação de laudos, exames periciais e IDs de comprovação da materialidade e autoria; registro de confissão ou interrogatório em sede policial.
5. **Histórico Processual Cronológico:** Linha do tempo de todos os atos e expedientes relevantes no formato rigoroso: `DD/MM/AA: [Descrição do Ato/Decisão/Manifestação/Certidão] (ID [número])`.
6. **Testemunhas (Acusação e Defesa):** Relação numerada contendo nome, qualificação/papel (vítima, policial militar, testemunha presencial), IDs de mandados, ofícios ou certidões de intimação/contrafé e requerimentos das partes.
7. **Fechamento:** Encerramento formal respeitoso ("Cordial e respeitosamente,").

### R3. Interface Web Local Moderna (Identidade Google Stitch & Nano Banana)
Interface gráfica web local, responsiva e elegante, implementada com base na estética Google Stitch e Nano Banana (cards informativos de alto contraste, tipografia limpa, paleta refinada, estados de carregamento claros):
1. Seleção intuitiva do motor de leitura (Modo IA vs. Modo Offline) com opção de configuração de chave de API do Gemini ou variável de ambiente.
2. Área de upload de arquivos PDF (drag-and-drop) dos autos completos do PJe.
3. Painel interativo para revisão, edição, acréscimo ou remoção de qualquer campo extraído (qualificação, fatos, itens do histórico, testemunhas) antes da geração final.
4. Pré-visualização em tempo real do resumo formatado.
5. Botão de geração e download com 1 clique do arquivo `.docx` final.

### R4. Gerador de Documentos DOCX com Formatação Idêntica às Referências
Exportação de arquivos `.docx` formatados com os estilos, fontes, espaçamentos, negritos e links de reunião correspondentes aos modelos fornecidos pelo usuário.

### R5. Suíte de Testes e Validação Automatizada
Testes automatizados que validem o pipeline de ingestão e a fidelidade da extração em relação aos 9 casos de teste presentes no diretório de trabalho, verificando a presença de todos os campos-chave, formatos de IDs e coerência do documento gerado.

## Acceptance Criteria

### Motores e Processamento
- [ ] O usuário pode alternar entre o Modo 1 (IA) e o Modo 2 (Offline) diretamente pela interface.
- [ ] No Modo 2 (Offline), o sistema executa a extração sem conexões de rede ativas.
- [ ] O motor lida com arquivos PDF que contenham tanto páginas de texto nativo quanto páginas digitalizadas (imagens/OCR).

### Fidelidade e Estrutura dos Resumos
- [ ] O resumo gerado contém exatamente as 6 seções estruturadas: Cabeçalho com IDs, Qualificação, Imputação, Resumo dos Fatos, Histórico Processual cronológico com IDs e Rol de Testemunhas com status de intimação.
- [ ] No Histórico Processual, cada linha segue o padrão `DD/MM/AA: [Ato] (ID [número])`.
- [ ] Em denúncias padrão, os fatos são preservados na íntegra; em denúncias excessivamente longas, é gerada síntese concisa preservando autoria, materialidade e conduta imputada.

### Usabilidade e Edição
- [ ] A aplicação web inicializa localmente no Windows e abre no navegador.
- [ ] Permite ao usuário carregar um PDF dos autos do PJe e visualiza o resultado em tela.
- [ ] Cada seção extraída é editável pelo usuário na interface antes da exportação.
- [ ] O arquivo `.docx` baixado abre no Microsoft Word com formatação visualmente idêntica aos arquivos de referência.

### Verificação Programática
- [ ] Scripts de teste executam nos casos existentes na pasta de trabalho e verificam que os campos de processo, réus, artigos e datas de atos com IDs são extraídos corretamente.
